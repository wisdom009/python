keys = input().split()
values = map(float, input().split())
lux = dict(zip(keys, values))

print(lux)