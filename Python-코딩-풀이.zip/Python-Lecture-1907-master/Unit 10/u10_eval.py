increment = int(input())
t = tuple(range(-10, 10, increment))

print(t)