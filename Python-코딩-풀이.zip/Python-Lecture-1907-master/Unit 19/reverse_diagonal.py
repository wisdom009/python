for i in reversed(range(5)):
    for k in range(i):
        print(' ', end='')
    print('*')
