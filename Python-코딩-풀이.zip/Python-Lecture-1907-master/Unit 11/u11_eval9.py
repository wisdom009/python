a, b = input().split()
s = a[1::2] + b[::2]     # 인덱스가 홀수 + 인덱스가 짝수

print(s)