x = input().split()
del x[-5:]

print(tuple(x))