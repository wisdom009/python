x =input().split()  #1 2 3 4 5 6 7 8 9 10
x[0:5]
x =input().split()
#oven bat pony total leak wreck curl crop space navy loss knee
x[0:8]

a = input()
#python
b = input()
#python

print(a[1::2] + b[::2])


