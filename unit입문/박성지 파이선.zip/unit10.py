tuple(range(-10,10,2))
tuple(range(-10,10,3))