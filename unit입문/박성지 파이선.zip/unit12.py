

x = dict(zip(['health', 'health_regen', 'mana', 'mana_regen'],
             [575.6, 1.7, 338.8, 1.63]))
x

a = input().split()

#health health_regen mana mana_regen

b =input().split()

#575.6 1.7 338.8 1.63

c = dict(zip(a,b))

q =input().split()
#health mana melee attack_speed magic_resistance
w =input().split()
#573.6 308.8 600 0.625 35.7
e = dict(zip(q,w))


